module.exports = [
    {
        "repoId": "499",
        "type": "cssUrl",
        "output": "./index.html",
        "apiUrl": "http://icon.bolin.site/api/repo/{repoId}/resource"
    }
];

## nicon-front

nicon-front工程是字体图标管理平台的前端项目，是个可以独立启动的前端工程，而接口依赖[nicon](https://github.com/bolin-L/nicon)工程，具体的平台部署需要参考[nicon](https://github.com/bolin-L/nicon)。

nicon-front是一个单页面的应用，采用Vue等相关技术栈。工程中具体结构设计、代码组织方式都是根据个人喜好来实现的。在开发过程中，提取了一些通用组件以及异步接口管理模块[axios-cache](https://github.com/bolin-L/axios-cache)，有兴趣的可以看看

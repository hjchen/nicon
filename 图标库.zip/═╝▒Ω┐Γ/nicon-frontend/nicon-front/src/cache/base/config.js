export default {
    'upload': {
        url: 'api/upload/file',
        method: 'post'
    }
}

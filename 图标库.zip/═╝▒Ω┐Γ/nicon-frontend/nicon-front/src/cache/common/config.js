export default {
    'install-application': {
        url: '/api/install',
        method: 'post'
    }
}

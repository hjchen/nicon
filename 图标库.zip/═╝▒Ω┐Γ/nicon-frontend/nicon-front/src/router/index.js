import Hello from '@/components/index/indexHello/ui'

export default [
    {
        path: '/',
        name: 'indexHello',
        component: Hello
    }
]

import Install from '@/modules/install/ui'

export default [
    {
        path: '/install',
        name: 'install',
        component: Install
    }
]

import Base from '@/base/base.vue'
export default Base.extend({
    data () {
        return {
            classes: ''
        }
    },
    methods: {

    }
})

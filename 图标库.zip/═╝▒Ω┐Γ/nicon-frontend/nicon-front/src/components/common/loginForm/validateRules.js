let validator = {
    userName: [
        {
            type: 'isRequired',
            message: '请填写邮箱账号'
        }
    ],
    password: [
        {
            type: 'isRequired',
            message: '请填写密码'
        }
    ]
}

export default validator

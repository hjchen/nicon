// index page recommend repo

module.exports = {
    id: {type: Number, unique: true}, // recommend id
    repoId: {type: Number, unique: true}, // repo id
    repoName: String // repo name
};

module.exports = {
    level: 'debug',
    root: '../logs/'
};

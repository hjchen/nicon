module.exports = {
    /* 添加成员输入类型-用户ID */
    MEMBER_ACCOUNT_TYPE_USER_ID: 1,

    /* 添加成员输入类型-邮箱 */
    MEMBER_ACCOUNT_TYPE_USER_NAME: 5,

    /* 图标仓库列表图标库返回图标个数 */
    REPO_LIST_CONTAIN_ICON_COUNT_PER_REPO: 15
};

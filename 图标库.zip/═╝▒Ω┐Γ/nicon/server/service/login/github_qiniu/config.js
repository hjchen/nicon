let config = require('../github/config');
module.exports = config;

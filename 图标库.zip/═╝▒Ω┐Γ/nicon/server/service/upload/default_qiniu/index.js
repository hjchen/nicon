let upload = require('../qiniu/index');
module.exports = upload;

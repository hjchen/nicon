var gulp = require('gulp');

require('./server/tool/icon');

module.exports = gulp;
